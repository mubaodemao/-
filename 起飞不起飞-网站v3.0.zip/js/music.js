/* ===== 氛围音乐卡片（v2）：网页实时合成 BGM，可开/关/隐藏/拖动，文字与抽奖结果同步 ===== */
window.LF_Music = (function () {
  'use strict';

  var ctx = null;      /* 音频上下文 */
  var master = null;   /* 主音量总线 */
  var playing = false; /* 是否正在播放 */
  var timer = null;    /* 调度定时器 */
  var nextTime = 0;    /* 下一个音符的时间点 */
  var step = 0;        /* 八分音符步进计数 */
  var HIDE_KEY = 'lfq.musicHidden';   /* 记住用户是否隐藏了卡片 */
  var PAUSE_KEY = 'lfq.musicManualPause'; /* 记住用户是否手动暂停过 */
  var POS_KEY = 'lfq.musicPos';       /* 记住卡片拖拽位置 */
  var d = document;

  /* 四小节循环：C - Am - F - G，每小节 4 拍（BPM 100） */
  var CHORDS = [
    [48, 52, 55],  /* C  */
    [45, 48, 52],  /* Am */
    [41, 45, 48],  /* F  */
    [43, 47, 50]   /* G  */
  ];
  /* 高音旋律：相对和弦根音 +24，-1 表示休止（32 个八分音符 = 4 小节） */
  var MELODY = [
    12, -1, 16, 12, -1, 19, 16, -1,
    -1, 12, 15, -1, 19, -1, 17, 15,
    12, -1, 15, 17, -1, 12, -1, 10,
    14, -1, 12, 10, 12, -1, -1, -1
  ];

  var mtof = function (m) { return 440 * Math.pow(2, (m - 69) / 12); };

  /* 获取（并唤醒）音频上下文 */
  function audio() {
    try {
      if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === 'suspended') ctx.resume();
      return ctx;
    } catch (e) { return null; }
  }

  /* 播放一个音符 */
  function note(t0, midi, dur, type, vol) {
    try {
      var o = ctx.createOscillator();
      var g = ctx.createGain();
      o.type = type || 'triangle';
      o.frequency.value = mtof(midi);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol, t0 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g);
      g.connect(master);
      o.start(t0);
      o.stop(t0 + dur + 0.05);
    } catch (e) {}
  }

  var noiseBuf = null;
  /* 轻 hi-hat：用白噪声做成小打击声 */
  function hat(t0) {
    try {
      if (!noiseBuf) {
        noiseBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.05), ctx.sampleRate);
        var ch = noiseBuf.getChannelData(0);
        for (var i = 0; i < ch.length; i++) ch[i] = (Math.random() * 2 - 1) * (1 - i / ch.length);
      }
      var src = ctx.createBufferSource();
      src.buffer = noiseBuf;
      var g = ctx.createGain();
      g.gain.value = 0.016;
      src.connect(g);
      g.connect(master);
      src.start(t0);
    } catch (e) {}
  }

  /* 按节拍调度音符（提前量 0.4 秒） */
  function schedule() {
    var spb = 0.3; /* 八分音符时长：BPM100 下每拍 0.6 秒 */
    while (nextTime < ctx.currentTime + 0.4) {
      var bar = Math.floor(step / 8) % 4; /* 每 8 个八分音符切换一个小节 */
      var st = step % 8;
      var root = CHORDS[bar][0];
      /* 低音：每小节第 1、5 个八分音符 */
      if (st === 0 || st === 4) {
        note(nextTime, root - 12, 0.55, 'sine', 0.16);
      }
      /* 分解和弦琶音：六音循环 */
      var ARP = [12, 16, 19, 24, 19, 16];
      note(nextTime, root + ARP[step % 6], 0.26, 'triangle', 0.04);
      /* 高音旋律 */
      var m = MELODY[step % 32];
      if (m >= 0) {
        note(nextTime, root + 24 + m, 0.27, 'triangle', 0.055);
      }
      /* 轻 hi-hat：每两拍一下 */
      if (step % 2 === 0) hat(nextTime);
      nextTime += spb;
      step++;
    }
  }

  /* 开始播放循环 */
  function start() {
    if (!audio()) return;
    if (!master) {
      master = ctx.createGain();
      master.gain.value = 0.55;
      master.connect(ctx.destination);
    }
    if (timer) clearInterval(timer);
    nextTime = ctx.currentTime + 0.08;
    step = 0;
    timer = setInterval(schedule, 120);
    playing = true;
    updateBtn();
  }

  /* 暂停播放 */
  function pause() {
    if (timer) { clearInterval(timer); timer = null; }
    playing = false;
    updateBtn();
  }

  /* 按钮触发：手动暂停/播放，并记忆偏好（避免切页后又自动响） */
  function toggle() {
    if (playing) {
      pause();
      try { localStorage.setItem(PAUSE_KEY, '1'); } catch (e) {}
    } else {
      start();
      try { localStorage.removeItem(PAUSE_KEY); } catch (e) {}
    }
  }
  function isManualPaused() { try { return localStorage.getItem(PAUSE_KEY) === '1'; } catch (e) { return false; } }

  /* 按钮文案 */
  function updateBtn() {
    var btn = d.getElementById('mcBtn');
    if (btn) btn.textContent = playing ? '⏸ 暂停音乐' : '🎵 播放音乐';
    var fl = d.getElementById('musicFloat');
    if (fl) fl.classList.toggle('playing', playing);
  }

  /* 隐藏状态 */
  function isHiddenPref() { try { return localStorage.getItem(HIDE_KEY) === '1'; } catch (e) { return false; } }
  function applyHidden() {
    var card = d.getElementById('musicCard');
    var fl = d.getElementById('musicFloat');
    if (!card) return;
    var hidden = isHiddenPref();
    card.style.display = hidden ? 'none' : '';
    if (fl) fl.hidden = !hidden;
    /* 最小化卡片时保持当前播放状态，音乐继续 */
  }

  /* 同步抽奖结果文字到卡片 */
  function setText(word, saying) {
    var w = d.getElementById('mcW');
    var s = d.getElementById('mcS');
    if (w) w.textContent = word;
    if (s) s.textContent = saying;
  }

  /* 首次用户交互 → 自动开播（满足"点进来就放歌"），但卡片内点按钮不触发 */
  var autoBound = false;
  function tryAutoStart(e) {
    if (isHiddenPref()) return;                /* 隐藏过 → 不自动响 */
    if (isManualPaused()) return;              /* 手动停过 → 不自动响 */
    if (e && e.target && e.target.closest && e.target.closest('#musicCard')) return; /* 在卡片内操作交给按钮 */
    if (!playing) start();
  }
  function bindAuto() {
    if (autoBound) return;
    autoBound = true;
    ['pointerdown', 'touchstart', 'keydown'].forEach(function (ev) {
      d.addEventListener(ev, tryAutoStart, { passive: true });
    });
  }

  /* 拖拽移动卡片 */
  function initDrag(card, fl) {
    var drag = null;
    card.addEventListener('pointerdown', function (e) {
      if (e.target.closest('button')) return;  /* 按钮不触发拖动 */
      drag = { x: e.clientX, y: e.clientY, l: card.offsetLeft, t: card.offsetTop };
      try { card.setPointerCapture(e.pointerId); } catch (err) {}
      try { e.preventDefault(); } catch (err) {}
    });
    card.addEventListener('pointermove', function (e) {
      if (!drag) return;
      var nl = drag.l + e.clientX - drag.x;
      var nt = drag.t + e.clientY - drag.y;
      nl = Math.max(8, Math.min(nl, (window.innerWidth || 390) - card.offsetWidth - 8));
      nt = Math.max(8, Math.min(nt, (window.innerHeight || 800) - card.offsetHeight - 8));
      card.style.right = 'auto';
      card.style.bottom = 'auto';
      card.style.left = nl + 'px';
      card.style.top = nt + 'px';
    });
    function endDrag() {
      if (!drag) return;
      drag = null;
      try {
        localStorage.setItem(POS_KEY, JSON.stringify({ l: card.style.left, t: card.style.top }));
      } catch (e) {}
    }
    ['pointerup', 'pointercancel'].forEach(function (ev) {
      card.addEventListener(ev, endDrag);
    });
    /* 恢复上次拖拽位置 */
    try {
      var pos = JSON.parse(localStorage.getItem(POS_KEY) || 'null');
      if (pos && pos.l && pos.t) {
        card.style.right = 'auto';
        card.style.bottom = 'auto';
        card.style.left = pos.l;
        card.style.top = pos.t;
      }
    } catch (e) {}
  }

  /* 初始化：绑定按钮与拖动 */
  (function init() {
    var card = d.getElementById('musicCard');
    var btn = d.getElementById('mcBtn');
    var hideBtn = d.getElementById('mcHide');
    var fl = d.getElementById('musicFloat');
    if (!card) return; /* 页面没有音乐卡片就直接跳过 */
    if (btn) btn.addEventListener('click', function () { toggle(); });
    if (hideBtn) hideBtn.addEventListener('click', function () {
      try { localStorage.setItem(HIDE_KEY, '1'); } catch (e) {}
      applyHidden();
    });
    if (fl) fl.addEventListener('click', function () {
      try { localStorage.removeItem(HIDE_KEY); } catch (e) {}
      applyHidden();
    });
    initDrag(card, fl);
    applyHidden();
    bindAuto();
    updateBtn();
  })();

  return { setText: setText, play: start, pause: pause, toggle: toggle };
})();