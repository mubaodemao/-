/* ===== 音效 + 震动（读取设置开关） ===== */
window.LF_Sound = (function () {
  'use strict';

  var ctx = null;

  function audio() {
    try {
      if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === 'suspended') ctx.resume();
      return ctx;
    } catch (e) { return null; }
  }

  function enabled() {
    return !!window.LS && LS.load().sound !== false;
  }

  function tone(freq, dur, type, vol, delay, slideTo) {
    var ac = audio();
    if (!ac) return;
    try {
      var t0 = ac.currentTime + (delay || 0);
      var o = ac.createOscillator();
      var g = ac.createGain();
      o.type = type || 'sine';
      o.frequency.setValueAtTime(freq, t0);
      if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(vol || 0.14, t0 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(g);
      g.connect(ac.destination);
      o.start(t0);
      o.stop(t0 + dur + 0.03);
    } catch (e) {}
  }

  function vibrate(pattern) {
    try {
      if (window.LS && LS.load().vibrate === false) return;
      if (navigator.vibrate) navigator.vibrate(pattern);
    } catch (e) {}
  }

  function play(name) {
    if (!enabled()) return;
    switch (name) {
      case 'click': tone(720, 0.06, 'square', 0.05); break;
      case 'spin': tone(320, 0.55, 'sine', 0.07, 0, 130); break;
      case 'success':
        tone(523, 0.1, 'sine', 0.12);
        tone(659, 0.1, 'sine', 0.12, 0.09);
        tone(784, 0.18, 'sine', 0.12, 0.18);
        break;
      case 'celebrate':
        [523, 659, 784, 1047, 1319].forEach(function (f, i) { tone(f, 0.24, 'triangle', 0.12, i * 0.12); });
        break;
      case 'save': tone(880, 0.09, 'sine', 0.1); break;
    }
  }

  return { play: play, vibrate: vibrate };
})();
