/* ===== 全局设置 + 数据备份 ===== */
window.LS = (function () {
  'use strict';

  var KEY = 'lfq.settings';
  var DATA_KEYS = ['lfq.results', 'lfq.endure', 'lfq.picks', 'lfq.lastResult', 'lfq.times', 'lfq.settings', 'lfq.celebrated'];

  var DEFAULTS = { bgOp: 1, fontScale: 1, sound: true, vibrate: true };

  function load() {
    try {
      var v = JSON.parse(localStorage.getItem(KEY));
      return Object.assign({}, DEFAULTS, v || {});
    } catch (e) { return Object.assign({}, DEFAULTS); }
  }
  function save(s) {
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {}
  }
  function set(patch) {
    var s = load();
    Object.assign(s, patch);
    save(s);
    apply();
    return s;
  }

  /* 应用设置到页面：背景透明度 + 整体缩放 */
  function apply() {
    var s = load();
    document.documentElement.style.setProperty('--bg-op', s.bgOp);
    document.documentElement.style.zoom = s.fontScale;
  }

  /* ---------- 导出 / 导入 ---------- */
  function exportData() {
    var out = {};
    DATA_KEYS.forEach(function (k) {
      var v = localStorage.getItem(k);
      if (v != null) out[k] = v;
    });
    var blob = new Blob([JSON.stringify(out, null, 2)], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    var d = new Date();
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    a.download = '起飞不起飞-备份-' + d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + '.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000);
  }

  function importData(file) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () {
        try {
          var obj = JSON.parse(r.result);
          Object.keys(obj).forEach(function (k) { localStorage.setItem(k, obj[k]); });
          apply();
          resolve(true);
        } catch (e) { reject(e); }
      };
      r.onerror = function () { reject(r.error); };
      r.readAsText(file);
    });
  }

  /* ---------- 设置页逻辑 ---------- */
  function initPage() {
    var app = document.getElementById('settingsApp');
    if (!app) return;
    var s = load();

    var bgOp = document.getElementById('bgOp');
    var bgOpVal = document.getElementById('bgOpVal');
    if (bgOp) {
      bgOp.value = s.bgOp;
      bgOpVal.textContent = Math.round(s.bgOp * 100) + '%';
      bgOp.addEventListener('input', function () {
        bgOpVal.textContent = Math.round(this.value * 100) + '%';
        set({ bgOp: parseFloat(this.value) });
      });
    }

    var fontBtns = document.querySelectorAll('[data-font]');
    fontBtns.forEach(function (b) {
      if (b.getAttribute('data-font') === String(s.fontScale)) b.classList.add('on');
      b.addEventListener('click', function () {
        fontBtns.forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on');
        set({ fontScale: parseFloat(b.getAttribute('data-font')) });
      });
    });

    function bindSwitch(id, key) {
      var el = document.getElementById(id);
      if (!el) return;
      el.checked = !!s[key];
      el.addEventListener('change', function () { set((function (o) { o[key] = el.checked; return o; })({})); });
    }
    bindSwitch('optSound', 'sound');
    bindSwitch('optVibrate', 'vibrate');

    var expBtn = document.getElementById('exportBtn');
    if (expBtn) expBtn.addEventListener('click', function () { exportData(); });

    var clearBtn = document.getElementById('clearDataBtn');
    if (clearBtn) clearBtn.addEventListener('click', function () {
      if (!confirm('确定清空所有「今日不起飞」打卡记录吗？此操作不可恢复！')) return;
      localStorage.removeItem('lfq.endure');
      localStorage.removeItem('lfq.celebrated');
      alert('✅ 打卡数据已清空，连续天数已归零');
    });

    var impBtn = document.getElementById('importBtn');
    var impFile = document.getElementById('importFile');
    if (impBtn && impFile) impBtn.addEventListener('click', function () { impFile.click(); });
    if (impFile) impFile.addEventListener('change', function () {
      if (!impFile.files.length) return;
      importData(impFile.files[0]).then(function () {
        alert('✅ 导入成功，数据已恢复！');
        impFile.value = '';
      }).catch(function () {
        alert('❌ 导入失败，请检查备份文件格式');
      });
    });
  }

  apply();
  initPage();

  return { load: load, save: save, set: set, apply: apply, exportData: exportData, importData: importData };
})();