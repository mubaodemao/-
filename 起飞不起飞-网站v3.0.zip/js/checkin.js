/* ===== 今天起飞不起飞 —— 今日不起飞页 ===== */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };

  function todayStr() {
    var d = new Date();
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }

  var CHEER = [
    '今天不起飞，攒劲！💤',
    '干得漂亮，稳住就是胜利 👍',
    '意志力 +1，起飞能量正在攒满 ✈️',
    '很好的选择，明天会更好！',
    '自律的每一秒都算数，加油！'
  ];

  /* ---------- Toast ---------- */
  var toastTimer = null;
  function toast(msg) {
    var t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 1900);
  }

  /* ---------- 渲染 ---------- */
  function renderStats() {
    var endure = LFCalendar.loadEndure();
    var today = todayStr();

    $('weekNum').textContent = LFCalendar.endureWeekDays() + '/7';
    $('streakNum').textContent = LFCalendar.enduranceStreak();

    var btn = $('endureBtn');
    var status = $('endureStatus');
    if (endure[today]) {
      btn.textContent = '✅ 今天已不起飞';
      btn.disabled = true;
      status.hidden = false;
    } else {
      btn.textContent = '💤 今日不起飞';
      btn.disabled = false;
      status.hidden = true;
    }
  }

  /* ---------- 勋章（不起飞版本） ---------- */
  function renderBadges() {
    var box = $('badgeBox');
    if (!box) return;
    var streak = LFCalendar.enduranceStreak();
    box.innerHTML = '';
    LFCalendar.BADGES.forEach(function (b) {
      var el = document.createElement('span');
      el.className = 'badge' + (streak >= b.days ? '' : ' locked');
      el.innerHTML = b.icon + ' ' + b.name + ' ' + b.days + '天';
      box.appendChild(el);
    });
  }

  /* ---------- 打卡 ---------- */
  $('endureBtn').addEventListener('click', function () {
    LFCalendar.recordEndure(todayStr(), true);
    LF_Sound.play('success');
    LF_Sound.vibrate(30);
    toast(CHEER[Math.floor(Math.random() * CHEER.length)]);
    renderStats();
    renderBadges();
    cal.refresh();
  });

  /* ---------- 初始化 ---------- */
  var cal = LFCalendar.render($('calBox'));
  renderStats();
  renderBadges();
})();
