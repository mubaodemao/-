/* ===== 今天起飞不起飞 —— 共享日历 + 记录数据 ===== */
window.LFCalendar = (function () {
  'use strict';

  var RESULTS_KEY = 'lfq.results';   // { 'YYYY-MM-DD': 'big'|'fly'|'small'|'idle' }
  var ENDURE_KEY = 'lfq.endure';     // { 'YYYY-MM-DD': true } 今日不起飞打卡
  var PICKS_KEY = 'lfq.picks';       // 每次抽取累计：{ big:n, fly:n, small:n, idle:n }
  var WEEK = ['一', '二', '三', '四', '五', '六', '日'];

  var KIND_EMOJI = { big: '🚀', fly: '✈️', small: '🪁', idle: '🛋️' };
  var ENDURE_MARK = '💤';

  var BADGES = [
    { days: 3, name: '定力新秀', icon: '🧘' },
    { days: 7, name: '意志达人', icon: '💪' },
    { days: 14, name: '不动如山', icon: '🗿' },
    { days: 30, name: '坐怀不乱', icon: '👑' }
  ];

  /* 首页"起飞勋章"：连续"起飞"天数（当天结果非不起飞）解锁 */
  var FLY_BADGES = [
    { days: 3, name: '小飞侠', icon: '🐣' },
    { days: 7, name: '飞天达人', icon: '🚁' },
    { days: 14, name: '起飞之神', icon: '🚀' },
    { days: 30, name: '传奇机长', icon: '👑' }
  ];

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dateStr(d) {
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function load(key, fb) {
    try { var v = JSON.parse(localStorage.getItem(key)); return v == null ? fb : v; }
    catch (e) { return fb; }
  }
  function save(key, val) {
    try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
  }

  function loadResults() { return load(RESULTS_KEY, {}); }
  function loadEndure() { return load(ENDURE_KEY, {}); }

  function recordResult(date, kind) {
    var o = loadResults();
    o[date] = kind;
    save(RESULTS_KEY, o);
  }
  function recordEndure(date, on) {
    var o = loadEndure();
    if (on) { o[date] = true; } else { delete o[date]; }
    save(ENDURE_KEY, o);
  }

  /* 每种结果出现的累计天数（按天） */
  function countByKind() {
    var c = { big: 0, fly: 0, small: 0, idle: 0 };
    var results = loadResults();
    Object.keys(results).forEach(function (k) {
      var v = results[k];
      if (c[v] != null) c[v]++;
    });
    return c;
  }

  /* 每次抽取累计次数 */
  function loadPicks() {
    var p = load(PICKS_KEY, null);
    if (!p) return { big: 0, fly: 0, small: 0, idle: 0 };
    ['big', 'fly', 'small', 'idle'].forEach(function (k) { if (p[k] == null) p[k] = 0; });
    return p;
  }
  function recordPick(kind) {
    var p = loadPicks();
    if (p[kind] == null) p[kind] = 0;
    p[kind]++;
    save(PICKS_KEY, p);
    return p;
  }

  /* 连续"今日不起飞"天数：今天已记录则从今天算；今天未记录则从昨天算 */
  function enduranceStreak() {
    var endure = loadEndure();
    var d = new Date();
    if (!endure[dateStr(d)]) d.setDate(d.getDate() - 1);
    var n = 0;
    while (endure[dateStr(d)]) {
      n++;
      d.setDate(d.getDate() - 1);
      if (n > 3650) break;
    }
    return n;
  }

  /* 连续"起飞"天数：当天抽取结果非不起飞（big/fly/small 都算起飞） */
  function flyStreak() {
    var results = loadResults();
    var d = new Date();
    if (!results[dateStr(d)]) d.setDate(d.getDate() - 1);
    var n = 0;
    while (results[dateStr(d)] && results[dateStr(d)] !== 'idle') {
      n++;
      d.setDate(d.getDate() - 1);
      if (n > 3650) break;
    }
    return n;
  }

  /* 近 7 天（含今天）"今日不起飞"天数 */
  function endureWeekDays() {
    var endure = loadEndure();
    var n = 0;
    var d = new Date();
    for (var i = 0; i < 7; i++) {
      var t = new Date(d);
      t.setDate(d.getDate() - i);
      if (endure[dateStr(t)]) n++;
    }
    return n;
  }

  /* ---------- 日历渲染 ---------- */
  function render(container) {
    var today = new Date();
    var state = { year: today.getFullYear(), month: today.getMonth() };
    var results = loadResults();
    var endure = loadEndure();

    container.classList.add('cal');
    container.innerHTML = '';

    var head = document.createElement('div');
    head.className = 'cal-head';
    var prev = document.createElement('button');
    prev.type = 'button'; prev.textContent = '‹';
    var title = document.createElement('span');
    title.className = 'cal-title';
    var next = document.createElement('button');
    next.type = 'button'; next.textContent = '›';
    head.appendChild(prev);
    head.appendChild(title);
    head.appendChild(next);
    container.appendChild(head);

    var wrow = document.createElement('div');
    wrow.className = 'cal-week';
    WEEK.forEach(function (w) {
      var s = document.createElement('span');
      s.textContent = w;
      wrow.appendChild(s);
    });
    container.appendChild(wrow);

    var grid = document.createElement('div');
    grid.className = 'cal-grid';

    function draw() {
      title.textContent = state.year + ' 年 ' + (state.month + 1) + ' 月';
      grid.innerHTML = '';
      var first = new Date(state.year, state.month, 1);
      var startPad = (first.getDay() + 6) % 7; // 周一为第一列
      var days = new Date(state.year, state.month + 1, 0).getDate();
      var i;
      for (i = 0; i < startPad; i++) {
        var blank = document.createElement('span');
        blank.className = 'cal-cell blank';
        grid.appendChild(blank);
      }
      for (var d = 1; d <= days; d++) {
        var date = new Date(state.year, state.month, d);
        var ds = dateStr(date);
        var cell = document.createElement('span');
        cell.className = 'cal-cell';
        if (ds === dateStr(today)) cell.classList.add('today');
        // 颜色：起飞（big/fly/small）变绿；不起飞（💤 打卡或 idle 结果）变红
        var resKind = results[ds];
        var isIdle = !!endure[ds] || resKind === 'idle';
        var isFly = !isIdle && resKind && resKind !== 'idle';
        if (isFly) cell.classList.add('fly');
        else if (isIdle) cell.classList.add('idle');
        var num = document.createElement('b');
        num.textContent = d;
        cell.appendChild(num);
        // 每天只显示一个状态：优先"今日不起飞"💤，否则显示当天档位
        var mark = null;
        if (endure[ds]) {
          mark = ENDURE_MARK;
        } else if (resKind) {
          mark = KIND_EMOJI[resKind];
        }
        if (mark) {
          var m = document.createElement('i');
          m.textContent = mark;
          cell.appendChild(m);
        }
        grid.appendChild(cell);
      }
      container.appendChild(grid);
    }

    prev.addEventListener('click', function () {
      state.month--;
      if (state.month < 0) { state.month = 11; state.year--; }
      draw();
    });
    next.addEventListener('click', function () {
      state.month++;
      if (state.month > 11) { state.month = 0; state.year++; }
      draw();
    });

    draw();

    // 返回刷新句柄：抽取/打卡后调用，保持当前月份并读取最新数据
    return {
      refresh: function () {
        results = loadResults();
        endure = loadEndure();
        draw();
      }
    };
  }

  return {
    BADGES: BADGES,
    FLY_BADGES: FLY_BADGES,
    KIND_EMOJI: KIND_EMOJI,
    ENDURE_MARK: ENDURE_MARK,
    loadResults: loadResults,
    loadEndure: loadEndure,
    recordResult: recordResult,
    recordEndure: recordEndure,
    countByKind: countByKind,
    loadPicks: loadPicks,
    recordPick: recordPick,
    enduranceStreak: enduranceStreak,
    flyStreak: flyStreak,
    endureWeekDays: endureWeekDays,
    render: render
  };
})();
