/* ===== 数据报告：周报 / 月报 ===== */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var MODE = 'week';

  var KINDS = [
    { kind: 'big', word: '大飞特飞', emoji: '🚀' },
    { kind: 'fly', word: '起飞', emoji: '✈️' },
    { kind: 'small', word: '小飞一下', emoji: '🪁' },
    { kind: 'idle', word: '不起飞', emoji: '🛋️' }
  ];

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function dateStr(d) {
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function todayStr() { return dateStr(new Date()); }

  function load(key, fb) {
    try { var v = JSON.parse(localStorage.getItem(key)); return v == null ? fb : v; }
    catch (e) { return fb; }
  }
  function loadTimes() {
    var t = load('lfq.times', []);
    return Array.isArray(t) ? t : [];
  }

  /* 当前范围日期集合（周：最近 7 天；月：当月 1 日至今日） */
  function rangeDates() {
    var set = {};
    var today = new Date();
    if (MODE === 'month') {
      var first = new Date(today.getFullYear(), today.getMonth(), 1);
      for (var d = new Date(first); d <= today; d.setDate(d.getDate() + 1)) {
        set[dateStr(d)] = true;
      }
    } else {
      for (var i = 0; i < 7; i++) {
        var t = new Date(today);
        t.setDate(today.getDate() - i);
        set[dateStr(t)] = true;
      }
    }
    return set;
  }

  function fmtMs(ms) {
    ms = Math.max(0, ms | 0);
    var h = Math.floor(ms / 3600000);
    var m = Math.floor((ms % 3600000) / 60000);
    var sec = Math.floor((ms % 60000) / 1000);
    var milli = ms % 1000;
    var p3 = function (n) { return (n < 100 ? '0' : '') + (n < 10 ? '0' : '') + n; };
    return pad(h) + ':' + pad(m) + ':' + pad(sec) + '.' + p3(milli);
  }

  function render() {
    var dates = rangeDates();
    var results = LFCalendar.loadResults();
    var endure = LFCalendar.loadEndure();
    var times = loadTimes().filter(function (t) { return !!dates[t.date]; });

    // 各档天数
    var kindDays = { big: 0, fly: 0, small: 0, idle: 0 };
    var flyDays = 0;
    var endureDays = 0;
    Object.keys(dates).forEach(function (ds) {
      var k = results[ds];
      if (k && kindDays[k] != null) { kindDays[k]++; if (k !== 'idle') flyDays++; }
      if (endure[ds]) endureDays++;
    });

    // 计时
    var timeCount = times.length;
    var total = 0, max = 0;
    times.forEach(function (t) { total += t.ms; if (t.ms > max) max = t.ms; });
    var avg = timeCount ? Math.round(total / timeCount) : 0;

    $('rFlyDays').textContent = flyDays;
    $('rEndureDays').textContent = endureDays;
    $('rTimes').textContent = timeCount;
    $('rTotal').textContent = fmtMs(total);
    $('rAvg').textContent = fmtMs(avg);
    $('rMax').textContent = fmtMs(max);

    // 各档列表
    var box = $('rKinds');
    box.innerHTML = '';
    KINDS.forEach(function (k) {
      var n = kindDays[k.kind] || 0;
      var row = document.createElement('div');
      row.className = 'count-row';
      row.innerHTML = '<span class="c-ic">' + k.emoji + '</span><span class="c-name">' + k.word + '</span>' +
        '<span class="c-bar"><i style="width:' + Math.min(100, n * 20) + '%"></i></span>' +
        '<span class="c-num">' + n + ' 天</span>';
      box.appendChild(row);
    });

    // 总结语
    $('rSummary').textContent = buildSummary(flyDays, endureDays, timeCount, max, total);
  }

  function buildSummary(flyDays, endureDays, timeCount, max, total) {
    var days = MODE === 'month' ? new Date().getDate() : 7;
    var flyRate = Math.round(flyDays / days * 100);
    if (endureDays >= Math.max(3, days - flyDays) && endureDays > 0) {
      return '这段时间很克制，坚持「今日不起飞」' + endureDays + ' 天，自律的人最酷 💤';
    }
    if (flyRate >= 60) {
      return '起飞率高到 ' + flyRate + '%，这段时间火力全开！🚀';
    }
    if (max > 0) {
      return '最长一次起飞 ' + fmtMs(max) + '，共 ' + timeCount + ' 次，状态在线 ✈️';
    }
    if (total > 0) {
      return '累计起飞 ' + fmtMs(total) + '，慢慢积累，量变引起质变 ✨';
    }
    if (flyDays > 0 || endureDays > 0) {
      return (MODE === 'month' ? '本月' : '本周') + '起飞 ' + flyDays + ' 天、不起飞 ' + endureDays + ' 天，节奏自己掌握，继续加油！';
    }
        return '还没有数据，去首页转一下、到「今日不起飞」打个卡吧！';
  }

  var segBtns = document.querySelectorAll('#reportSeg button');
  segBtns.forEach(function (b) {
    b.addEventListener('click', function () {
      segBtns.forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on');
      MODE = b.getAttribute('data-range');
      render();
    });
  });

  render();
})();
