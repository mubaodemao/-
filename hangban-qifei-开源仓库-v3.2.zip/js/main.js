/* ===== 今天起飞不起飞 —— 决策页 ===== */
(function () {
  'use strict';

  /* ---------- 四档结果 ---------- */
  var LEVELS = [
    { kind: 'big',   word: '大飞特飞', emoji: '🚀', sayings: [
      '今天直接拉满，大飞特飞！',
      '火力全开，冲上云霄！',
      '史诗级起飞，拦都拦不住！',
      '今天状态无敌，狂飙模式开启！',
      '小撸怡情，大撸伤身，强撸灰飞湮灭！',
      '弹药满仓，火力全开，今夜无眠！',
      '十成功力，不留余力，冲就完事！',
      '黄袍加身，直接登基，今日你是帝！'
    ]},
    { kind: 'fly',   word: '起飞', emoji: '✈️', sayings: [
      '今天状态拉满，直接起飞！',
      '引擎已点火，冲就完了！',
      '天空才是极限，起飞！',
      '机会来了，先飞为敬！',
      '一飞冲天，快乐值直接拉满！',
      '人生苦短，该飞就飞，别留遗憾！',
      '今日手气滚烫，起飞姿势要帅！',
      '冲上云霄，让所有烦恼追不上你！'
    ]},
    { kind: 'small', word: '小飞一下', emoji: '🪁', sayings: [
      '今天小试牛刀，小飞一下',
      '轻轻起飞，养精蓄锐',
      '小小飞一下，攒攒手感',
      '温柔起步，稳步上升',
      '浅尝辄止，留点余量明天再来',
      '蜻蜓点水，点到为止，来日方长',
      '今日小酌一杯，微醺就够',
      '见好就收，快乐细水长流'
    ]},
    { kind: 'idle',  word: '不起飞', emoji: '🛋️', sayings: [
      '今天先蓄力，明天再飞',
      '不起飞，躺平也是修行 😌',
      '休息是为了飞得更远',
      '稳住底盘，来日方长',
      '贤者模式已开启，心如止水',
      '宝剑入库，马放南山，休息一天',
      '忍一时风平浪静，退一步明天再飞',
      '今日封枪，修身养性，攒个大招'
    ]}
  ];

  /* ---------- 轮盘定义：8 扇区，四档各 2 格 ---------- */
  /* ---------- 轮盘定义：4 扇区，按概率分配角度（大飞10% 起飞35% 小飞20% 不起飞35%） ---------- */
  var SEG_DEFS = [
    { kind: 'big',   emoji: '🚀', color: '#f59e0b', start: 0,   end: 36 },
    { kind: 'fly',   emoji: '✈️', color: '#22d3ee', start: 36,  end: 162 },
    { kind: 'small', emoji: '🪁', color: '#34d399', start: 162, end: 234 },
    { kind: 'idle',  emoji: '🛋️', color: '#6b7280', start: 234, end: 360 }
  ];

  /* ---------- 档位概率（百分比）：大飞10 / 起飞35 / 小飞20 / 不起飞35 ---------- */
  var WEIGHTS = { big: 10, fly: 35, small: 20, idle: 35 };

  /* ---------- 加权随机选档位 ---------- */
  function weightedKind() {
    var r = Math.random() * 100;
    var acc = 0;
    for (var i = 0; i < SEG_DEFS.length; i++) {
      acc += WEIGHTS[SEG_DEFS[i].kind];
      if (r < acc) return SEG_DEFS[i].kind;
    }
    return SEG_DEFS[SEG_DEFS.length - 1].kind;
  }

  /* ---------- 工具 ---------- */
  var $ = function (id) { return document.getElementById(id); };
  var todayStr = function () {
    var d = new Date();
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  };
  var pick = function (arr) { return arr[Math.floor(Math.random() * arr.length)]; };
  var rand = function (a, b) { return a + Math.random() * (b - a); };

  var KEY = 'lfq.lastResult';
  function loadResult() {
    try { return JSON.parse(localStorage.getItem(KEY)) || null; } catch (e) { return null; }
  }
  function saveResult(kind) {
    var mult = 1 + Math.floor(Math.random() * 10); // 1~10
    var data = { date: todayStr(), kind: kind, mult: mult, ts: Date.now() };
    try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) {}
    LFCalendar.recordResult(todayStr(), kind);
    LFCalendar.recordPick(kind);
    return data;
  }
  function levelOf(kind) {
    for (var i = 0; i < LEVELS.length; i++) {
      if (LEVELS[i].kind === kind) return LEVELS[i];
    }
    return LEVELS[0];
  }

  /* ---------- 结果渲染 ---------- */
  function renderVerdict(emojiEl, wordEl, sayingEl, dateEl, countEl, multEl, card, kind, mult) {
    var cfg = levelOf(kind);
    emojiEl.textContent = cfg.emoji;
    wordEl.textContent = cfg.word;
    wordEl.className = 'v-word ' + kind;
    var saying = pick(cfg.sayings);
    sayingEl.textContent = saying;
    if (window.LF_Music) LF_Music.setText(cfg.word, saying);
    dateEl.textContent = todayStr();
    var n = LFCalendar.loadPicks()[kind] || 0;
    countEl.textContent = '累计出现 ' + n + ' 次';
    if (multEl) {
      // 不起飞不显示倍率；起飞档位显示 ×N次
      if (mult && kind !== 'idle') {
        multEl.textContent = '×' + mult + '次';
        multEl.style.display = '';
      } else {
        multEl.textContent = '';
        multEl.style.display = 'none';
      }
    }
    card.classList.remove('big-takeoff', 'big-idle');
    if (kind === 'idle') {
      card.classList.add('big-idle');
    } else {
      card.classList.add('big-takeoff');
    }
  }

  /* 粒子彩带 */
  var PARTICLES = ['✈️', '🚀', '🪁', '☁️', '✨', '🔥', '🎉', '💫'];
  function burst(card) {
    for (var i = 0; i < 8; i++) {
      (function () {
        var p = document.createElement('span');
        p.className = 'particle';
        p.textContent = PARTICLES[Math.floor(Math.random() * PARTICLES.length)];
        p.style.left = (30 + Math.random() * 40) + '%';
        p.style.top = (30 + Math.random() * 40) + '%';
        p.style.setProperty('--dx', rand(-120, 120) + 'px');
        p.style.setProperty('--dy', rand(-140, 40) + 'px');
        p.style.fontSize = rand(16, 30) + 'px';
        card.appendChild(p);
        setTimeout(function () { p.remove(); }, 950);
      })();
    }
  }

  /* ---------- 按钮版 ---------- */
  var btnGo = $('btnGo');
  var verdictBtn = $('verdictBtn');
  btnGo.addEventListener('click', function () {
    if (isLocked()) return;
    LF_Sound.play('click');
    LF_Sound.vibrate(12);
    var kind = weightedKind(); /* 大飞10/起飞35/小飞20/不起飞35 */
    var saved = saveResult(kind);
    renderVerdict($('vb-emoji'), $('vb-word'), $('vb-saying'), $('vb-date'), $('vb-count'), $('vb-mult'), verdictBtn, kind, saved.mult);
    burst(verdictBtn);
    renderCounts();
    cal.refresh();
    renderFlyBadges();
  });

  /* ---------- 轮盘版 ---------- */
  var wheel = $('wheel');
  var currentRot = 0;
  var spinning = false;

  function buildWheel() {
    var stops = SEG_DEFS.map(function (d) {
      return d.color + ' ' + d.start + 'deg ' + d.end + 'deg';
    }).join(',');
    wheel.style.background = 'conic-gradient(from 0deg at 50% 50%, ' + stops + ')';

    for (var i = 0; i < SEG_DEFS.length; i++) {
      var d = SEG_DEFS[i];
      var mid = (d.start + d.end) / 2;
      var a = mid * Math.PI / 180;
      var el = document.createElement('div');
      el.className = 'wheel-seg';
      var r = 33;
      var x = 50 + r * Math.sin(a);
      var y = 50 - r * Math.cos(a);
      el.style.left = x + '%';
      el.style.top = y + '%';
      el.style.transform = 'translate(-50%,-50%)';
      el.style.flexDirection = 'column';
      el.style.fontSize = '20px';
      el.innerHTML = '<span style="font-size:24px; line-height:1">' + d.emoji + '</span>' +
        '<span style="font-size:11px; font-weight:700; color:rgba(255,255,255,.95); margin-top:2px; text-shadow:0 1px 3px rgba(0,0,0,.5)">' +
        levelOf(d.kind).word + '</span>';
      wheel.appendChild(el);
    }
  }
  buildWheel();

  function restoreToday() {
    var r = loadResult();
    if (r && r.date === todayStr()) {
      renderVerdict($('vb-emoji'), $('vb-word'), $('vb-saying'), $('vb-date'), $('vb-count'), $('vb-mult'), verdictBtn, r.kind, r.mult);
      var seg = -1;
      for (var i = 0; i < SEG_DEFS.length; i++) {
        if (SEG_DEFS[i].kind === r.kind) { seg = i; break; }
      }
      if (seg >= 0) {
        var center = (SEG_DEFS[seg].start + SEG_DEFS[seg].end) / 2;
        currentRot = 360 * 2 + (360 - center);
        wheel.style.transform = 'rotate(' + currentRot + 'deg)';
        wheel.style.transition = 'none';
        setTimeout(function () { wheel.style.transition = ''; }, 50);
      }
    }
  }
  restoreToday();

  function spin() {
    if (spinning || isLocked()) return;
    spinning = true;
    $('wheelGo').disabled = true;
    LF_Sound.play('spin');
    LF_Sound.vibrate(20);

    var kind = weightedKind();
    var seg = null;
    for (var i = 0; i < SEG_DEFS.length; i++) {
      if (SEG_DEFS[i].kind === kind) { seg = SEG_DEFS[i]; break; }
    }
    var center = seg ? (seg.start + seg.end) / 2 : 18;
    var cur = ((currentRot % 360) + 360) % 360;
    var delta = ((360 - center) - cur + 360) % 360;
    var spins = 360 * 7 + delta + rand(-14, 14);
    currentRot += spins;

    wheel.classList.add('spinning');
    wheel.style.transform = 'rotate(' + currentRot + 'deg)';

    var card = $('verdictWheel');
    setTimeout(function () {
      var saved = saveResult(kind);
      renderVerdict($('vw-emoji'), $('vw-word'), $('vw-saying'), $('vw-date'), $('vw-count'), $('vw-mult'), card, kind, saved.mult);
      burst(card);
      renderCounts();
      cal.refresh();
      renderFlyBadges();
      LF_Sound.play('success');
      LF_Sound.vibrate([40, 40, 60]);
      spinning = false;
      $('wheelGo').disabled = false;
    }, 2800);
  }
  $('wheelGo').addEventListener('click', function () { LF_Sound.play('click'); spin(); });

  /* ---------- 模式切换 ---------- */
  var segBtns = document.querySelectorAll('#modeSeg button');
  segBtns.forEach(function (b) {
    b.addEventListener('click', function () {
      segBtns.forEach(function (x) { x.classList.remove('on'); });
      b.classList.add('on');
      var mode = b.getAttribute('data-mode');
      $('panel-btn').hidden = mode !== 'btn';
      $('panel-wheel').hidden = mode !== 'wheel';
    });
  });

  /* ---------- 次数统计卡 ---------- */
  function renderCounts() {
    var box = $('countBox');
    if (!box) return;
    var counts = LFCalendar.loadPicks();
    var total = 0;
    LEVELS.forEach(function (l) { total += counts[l.kind] || 0; });
    box.innerHTML = '';
    LEVELS.forEach(function (l) {
      var n = counts[l.kind] || 0;
      var pct = total > 0 ? Math.round(n / total * 100) : 0;
      var row = document.createElement('div');
      row.className = 'count-row';
      row.innerHTML =
        '<span class="c-ic">' + l.emoji + '</span>' +
        '<span class="c-name">' + l.word + '</span>' +
        '<span class="c-bar"><i style="width:' + pct + '%"></i></span>' +
        '<span class="c-num">' + n + ' 次</span>';
      box.appendChild(row);
    });
  }

  /* ---------- 起飞勋章（连续起飞天数解锁） ---------- */
  function renderFlyBadges() {
    var box = $('badgeBox');
    if (!box) return;
    var streak = LFCalendar.flyStreak();
    box.innerHTML = '';
    LFCalendar.FLY_BADGES.forEach(function (b) {
      var el = document.createElement('span');
      el.className = 'badge' + (streak >= b.days ? '' : ' locked');
      el.innerHTML = b.icon + ' ' + b.name + ' ' + b.days + '天';
      box.appendChild(el);
    });
  }

  /* ---------- 起飞时间计时器 ---------- */
  var TIME_KEY = 'lfq.times';
  var timerStart = null;
  var timerInterval = null;
  var timerRunning = false;

  /* 时:分:秒.毫秒 */
  function fmtMs(ms) {
    ms = Math.max(0, ms | 0);
    var h = Math.floor(ms / 3600000);
    var m = Math.floor((ms % 3600000) / 60000);
    var sec = Math.floor((ms % 60000) / 1000);
    var milli = ms % 1000;
    var p2 = function (n) { return (n < 10 ? '0' : '') + n; };
    var p3 = function (n) { return (n < 100 ? '0' : '') + (n < 10 ? '0' : '') + n; };
    return p2(h) + ':' + p2(m) + ':' + p2(sec) + '.' + p3(milli);
  }

  /* ---------- 计时嘲讽：0.1秒~10分钟=杂鱼级嘲讽 / 10~30分钟=还行 / 30分钟以上=受不了 ---------- */
  var TAUNT_SHORT = [
    '杂鱼~！就这？还没开始就结束了？',
    '三秒真男人，名不虚传啊',
    '一秒男，你比外卖还快',
    '就这？我耳机都还没戴好你就完事了？',
    '兄弟，这速度不去跑百米真可惜了',
    '快得跟开了二倍速似的',
    '缴枪比缴械还快，人才啊',
    '你这不是起飞，是原地爆炸',
    '小撸怡情可以，但你这也太快了吧',
    '秒射冠军，非你莫属',
    '还没进入状态你就交卷了？',
    '你管这叫起飞？这叫放了个响屁'
  ];
  var TAUNT_MID = [
    '还行，勉强及格线',
    '有点东西，继续保持',
    '渐入佳境，老当益壮',
    '可以啊，有两下子',
    '稳中向好，别浪',
    '这持久度，勉强算个真男人',
    '不错不错，手速耐力都到位',
    '有点水平，继续冲'
  ];
  var TAUNT_LONG = [
    '受不了了！你是铁人吗？',
    '半小时了还不停？手不酸吗',
    '战神！你是不打算停了吗',
    '再这样下去真要擦破皮了',
    '你这不是撸，是修仙吧',
    '持久之王，膜拜了',
    '半小时起步，你是打算通宵？',
    '牛啊，这已经不是手速问题了，是意志力'
  ];
  function getTaunt(ms) {
    var m = ms / 60000;
    var arr, label;
    if (m < 10) { arr = TAUNT_SHORT; label = '杂鱼级'; }
    else if (m < 30) { arr = TAUNT_MID; label = '还行级'; }
    else { arr = TAUNT_LONG; label = '受不了级'; }
    return { text: arr[Math.floor(Math.random() * arr.length)], label: label };
  }

  function loadTimes() {
    try { var v = JSON.parse(localStorage.getItem(TIME_KEY)); return Array.isArray(v) ? v : []; }
    catch (e) { return []; }
  }
  function saveTimes(arr) {
    try { localStorage.setItem(TIME_KEY, JSON.stringify(arr)); } catch (e) {}
  }

  function renderTimer() {
    var times = loadTimes();
    var total = 0;
    var max = 0;
    times.forEach(function (t) { total += t.ms; if (t.ms > max) max = t.ms; });
    var avg = times.length ? Math.round(total / times.length) : 0;
    $('tTotal').textContent = times.length;
    $('tTotalTime').textContent = fmtMs(total);
    $('tAvg').textContent = fmtMs(avg);
    $('tMax').textContent = fmtMs(max);

    var list = $('tList');
    list.innerHTML = '';
    var recent = times.slice(-5).reverse();
    recent.forEach(function (t) {
      var row = document.createElement('div');
      row.className = 'time-row';
      row.innerHTML = '<span>' + t.date + '</span><b>' + fmtMs(t.ms) + '</b>';
      list.appendChild(row);
    });
    if (!recent.length) {
      list.innerHTML = '<div class="empty" style="padding:12px">还没有记录，点开始计时吧</div>';
    }
  }

  function timerTick() {
    if (!timerStart) return;
    var ms = Date.now() - timerStart;
    $('timerDisplay').textContent = fmtMs(ms);
    var t = getTaunt(ms);
    var tel = $('timerTaunt');
    if (tel) tel.textContent = t.label + '：' + t.text;
  }

  $('timerBtn').addEventListener('click', function () {
    if (isLocked()) return;
    if (!timerRunning) {
      timerStart = Date.now();
      timerRunning = true;
      $('timerBtn').textContent = '⏹ 结束';
      $('timerBtn').classList.add('timer-on');
      $('timerMsg').textContent = '计时中…保持起飞状态 ✈️';
      $('timerMsg').style.color = '';
      var tel0 = $('timerTaunt');
      if (tel0) tel0.textContent = '🐟 计时中…看看你是杂鱼还是战神';
      timerInterval = setInterval(timerTick, 100);
      timerTick();
    } else {
      var ms = Date.now() - timerStart;
      clearInterval(timerInterval);
      timerRunning = false;
      $('timerBtn').textContent = '▶ 开始';
      $('timerBtn').classList.remove('timer-on');
      var times = loadTimes();
      times.push({ date: todayStr(), start: timerStart, end: Date.now(), ms: ms });
      saveTimes(times);
      var tEnd = getTaunt(ms);
      $('timerMsg').textContent = '✅ 本次起飞 ' + fmtMs(ms) + '（' + tEnd.label + '），已记录！';
      $('timerMsg').style.color = 'var(--green)';
      var telEnd = $('timerTaunt');
      if (telEnd) telEnd.textContent = tEnd.label + '：' + tEnd.text;
      renderTimer();
    }
  });

  /* ---------- 今日已选择不起飞 → 锁定第一页 ---------- */
  function isLocked() {
    return !!LFCalendar.loadEndure()[todayStr()];
  }

  function applyLock() {
    var locked = isLocked();
    var banner = $('lockBanner');
    if (banner) banner.hidden = !locked;
    $('btnGo').disabled = locked;
    $('wheelGo').disabled = locked;
    $('wheelCenter').disabled = locked;
    $('timerBtn').disabled = locked;
    if (locked) {
      $('vb-saying').textContent = '今天已选择「今日不起飞」，起飞功能已锁定 💤';
      $('vw-saying').textContent = '今天已选择「今日不起飞」，起飞功能已锁定 💤';
      $('timerMsg').textContent = '今日不起飞，计时已锁定 💤';
      var telLk = $('timerTaunt');
      if (telLk) telLk.textContent = '💤 今日不起飞，计时已锁定';
    }
  }

  /* ---------- 初始化 ---------- */
  var cal = LFCalendar.render($('calBox'));
  renderCounts();
  renderFlyBadges();
  renderTimer();
  applyLock();

  /* ---------- 轮盘中心 GO 也可点击转动 ---------- */
  $('wheelCenter').addEventListener('click', function () {
    LF_Sound.play('click');
    spin();
  });
})();
